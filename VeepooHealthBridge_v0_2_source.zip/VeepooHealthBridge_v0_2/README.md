# Veepoo Health Bridge · v0.2 (código fuente; NO instalada)

Aplicación SwiftUI para iPhone. Objetivo: recuperar datos compatibles del reloj A2 y transmitir a HealthKit solo mediciones admisibles y verificadas. **No hay extracción de Veepoo implementada**: el SDK debe incorporarse y probarse contra el dispositivo físico.

## Lo que hay

- Escaneo BLE con CoreBluetooth; detección, **no** emparejamiento funcional del SDK.
- Modelo de mediciones con identificadores estables, fuente, método y verificación.
- Almacenamiento persistente en el sandbox iOS, importación JSON 1.0, exportación JSON y vista local.
- HealthKit: solicitud de permisos; escritura explícita de registros validados, no estimados; comprobación de ID para evitar reimportaciones del propio puente. La lectura de HealthKit puede ser denegada silenciosamente según permisos.
- Categorías: pulso, HRV-SDNN (NO RMSSD), pasos, peso, grasa corporal (fracción de 0 a 1), masa magra, SpO2 (fracción de 0 a 1), temperatura, presión sistólica/diastólica, sueño.
- No envía ECG a HealthKit (API de ECG de solo lectura). No exporta estimaciones ópticas de glucosa, ácido úrico o lípidos a biomarcadores clínicos.
- **No hay datos demo** y no se insertan valores fabricados.

## Limitaciones / pendientes antes de producción

1. Integrar físicamente el SDK oficial de https://github.com/HBandSDK/iOS_Ble_SDK y comprobar licencia, dependencias, firmas de API, permisos y compatibilidad con firmware A2 `02.52.01.00-5982`.
2. Implementar conexión y autenticación, lectura de capacidades y de cada historial compatible, timestamp correctos y normalización de unidades.
3. Deducir HRV SDNN únicamente si el algoritmo real está documentado; no convertir RMSSD a SDNN como si fueran equivalentes.
4. Evitar duplicados de G Band que ya estén en Salud (no solo los del puente), con una política explícita de reconciliación por tipo/instante/origen.
5. Validar escritura de tensión como correlación HealthKit (en v0.2 se guardan dos cantidades independientes), calidad de datos, seguridad en reposo, procesamiento en segundo plano, pruebas en dispositivo.
6. Compilar en macOS remoto con Xcode y firma propia para TestFlight. GitHub Actions solo ejecuta validación de compilación no firmada del simulador.

## Formato de importación JSON

```json
{
  "schemaVersion": 1,
  "device": "A2",
  "measurements": [
    {
      "id": "external-source-unique-id",
      "kind": "heartRate",
      "value": 72,
      "start": "2026-10-31T08:00:00Z",
      "end": "2026-10-31T08:00:00Z",
      "source": "verified-device-export",
      "method": "optical",
      "validated": false,
      "note": "Ejemplo de formato; no corresponde a una medición real"
    }
  ]
}
```
La línea de ejemplo es DOCUMENTACIÓN, no se importa automáticamente. `validated` debe ser true para escribir; comprobar de manera independiente es responsabilidad del usuario. Los datos peligrosamente poco fiables no tienen exportación automatizada.

## Preparación solo con iPhone

1. Copiar a repositorio GitHub privado mediante interfaz web, o subir usando un servicio Git. Mantener el proyecto completo.
2. Utilizar un runner macOS con Xcode y `xcodegen generate` seguido de `xcodebuild` para comprobar errores.
3. Configurar Apple Developer, identificador de paquete único, HealthKit entitlement, perfiles de aprovisionamiento, certificados y TestFlight.
4. No activar sincronización de mediciones hasta validar el A2 y la corrección de unidades.

### Política de privacidad

Predeterminado local, sin servidor ni analítica. Los archivos compartidos por el usuario contienen datos de salud sensibles y deben guardarse en ubicación privada. No abrir puertos ni distribuir trazados del reloj públicamente.
