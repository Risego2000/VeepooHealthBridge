# Implementación pendiente del adaptador de Veepoo

- Obtener el SDK oficial para iOS y revisar la licencia y la modalidad de distribución del binario.
- Inspeccionar el ejemplo del SDK en Xcode y determinar métodos reales para escaneo/conexión, lectura de capacidades y lectura de datos históricos.
- Crear un adaptador implementando `VeepooSDKAdapter` sin usar APIs inventadas.
- Hacer una matriz de compatibilidad con reloj A2; registro de permisos, nombre BLE, identificador y firmware.
- Normalizar zona horaria y horarios de sueño; distinguir medición real de estimación y fuente original.
- Introducir pruebas de sincronización, permisos denegados, interrupción BLE, importación parcial, duplicados y reinicio.
- Para una app distribuida, revisar obligaciones de privacidad de datos de salud y restricciones de Apple Developer.
